package com.nlz.instantinvoice.activity;

import static com.nlz.instantinvoice.Uitilty.Util.ChangeStatusBarColor;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.nlz.instantinvoice.BuildConfig;
import com.nlz.instantinvoice.R;
import com.nlz.instantinvoice.databinding.ActivityAboutBinding;

public class AboutActivity extends AppCompatActivity {

    private ActivityAboutBinding binding;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_about);

        ChangeStatusBarColor(this);

        binding.tvVersionName.setText("version : " + BuildConfig.VERSION_NAME);

        binding.tvDevName.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
