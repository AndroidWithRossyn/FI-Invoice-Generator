package com.nlz.instantinvoice.Uitilty;

public interface OnItemClick {
    void onClick(int value);
}
